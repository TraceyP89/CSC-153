﻿using System;
using System.IO;
using System.Windows.Forms;

/**
 * January 30, 2021
 * Tracey Pinckney
 * CSC 153
 * This program will display and calculate the prices to give the total sale.
 **/
namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                //Create variables to read the each line of the prices
                string[] everyLine = File.ReadAllLines("Sales.txt");
                double[] prices = new double[everyLine.Length];
                int calculator = 0;
                double total = 0;

                //Display each number on every line and calculate each number for the total
                foreach (string charge in everyLine)
                {
                    prices[calculator] = Convert.ToDouble(charge);
                    total += prices[calculator];
                    lstDisplay.Items.Add(prices[calculator]);
                    calculator++;

                }

                lstDisplay.Items.Add("\nTotal Sales: " + total.ToString("n"));

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
